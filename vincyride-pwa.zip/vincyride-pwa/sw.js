/* VincyRide service worker — makes the app open and work with poor or no signal.
 *
 * IMPORTANT: bump VERSION every time you redeploy, so phones pick up the new files.
 *
 * Strategies:
 *   App page (index.html)   network-first (4s timeout) -> falls back to the saved copy.
 *                           Fresh when there's signal, still opens when there isn't.
 *   Icons, manifest         stale-while-revalidate (instant, refreshed in background)
 *   MapLibre library (CDN)  cache-first (never changes at a fixed version)
 *   Map tiles               stale-while-revalidate, capped at MAX_TILES, so areas you
 *                           have already viewed still show up offline
 *   Everything else         left alone (network)
 */
const VERSION   = 'v4';
const SHELL     = `vincyride-shell-${VERSION}`;
const LIBS      = 'vincyride-libs-v1';
const TILES     = `vincyride-tiles-${VERSION}`;
const MAX_TILES = 500;
const NET_TIMEOUT_MS = 4000;

const SHELL_FILES = [
  './', './index.html', './manifest.json',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png', './icons/favicon-32.png', './icons/icon.svg'
];
const LIB_FILES = [
  'https://cdnjs.cloudflare.com/ajax/libs/maplibre-gl/5.2.0/maplibre-gl.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/maplibre-gl/5.2.0/maplibre-gl.min.css'
];
const TILE_HOSTS = ['tile.openstreetmap.org', 'server.arcgisonline.com', 'elevation-tiles-prod'];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const shell = await caches.open(SHELL);
    await shell.addAll(SHELL_FILES);                       // must all succeed: this is the app itself
    const libs = await caches.open(LIBS);
    await Promise.all(LIB_FILES.map(async url => {         // best effort: fine if the venue is offline at install
      try { if (!(await libs.match(url))) { const r = await fetch(url, {mode:'cors'}); if (r.ok) await libs.put(url, r); } }
      catch (e) { /* will be cached the first time it loads with internet */ }
    }));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keep = [SHELL, LIBS, TILES];
    for (const k of await caches.keys()) if (!keep.includes(k)) await caches.delete(k);   // clear old versions
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // 1) The app page itself
  if (req.mode === 'navigate') { event.respondWith(networkFirstPage(req)); return; }

  // 2) MapLibre library files
  if (LIB_FILES.includes(req.url)) { event.respondWith(cacheFirst(req, LIBS)); return; }

  // 3) Map tiles
  if (TILE_HOSTS.some(h => url.hostname.includes(h))) { event.respondWith(staleWhileRevalidate(req, TILES, MAX_TILES)); return; }

  // 4) Our own static files (icons, manifest)
  if (url.origin === self.location.origin) { event.respondWith(staleWhileRevalidate(req, SHELL)); return; }
});

async function networkFirstPage(req) {
  const cache = await caches.open(SHELL);
  try {
    const res = await Promise.race([
      fetch(req),
      new Promise((_, rej) => setTimeout(() => rej(new Error('slow network')), NET_TIMEOUT_MS))
    ]);
    if (res && res.ok) cache.put('./index.html', res.clone());   // keep the saved copy fresh
    return res;
  } catch (e) {
    return (await cache.match('./index.html')) || (await cache.match('./')) ||
           new Response('VincyRide is offline and has not been saved on this device yet. Open it once with internet.',
                        {status: 503, headers: {'Content-Type': 'text/plain'}});
  }
}
async function cacheFirst(req, name) {
  const cache = await caches.open(name);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && res.ok) cache.put(req, res.clone());
  return res;
}
async function staleWhileRevalidate(req, name, max) {
  const cache = await caches.open(name);
  const hit = await cache.match(req);
  const refresh = fetch(req).then(async res => {
    if (res && res.ok) {                                   // never cache opaque/failed responses (they bloat storage)
      await cache.put(req, res.clone());
      if (max) trim(cache, max);
    }
    return res;
  }).catch(() => null);
  return hit || (await refresh) || new Response('', {status: 504});
}
async function trim(cache, max) {
  const keys = await cache.keys();
  for (let i = 0; i < keys.length - max; i++) await cache.delete(keys[i]);   // oldest first
}
