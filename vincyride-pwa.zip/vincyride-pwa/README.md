# VincyRide — PWA guide (Parts 1–10)

VincyRide is a Progressive Web App: one website that installs on a phone like a real app,
opens full-screen, and keeps working with weak or no signal.

## What's in this folder

```
vincyride-pwa/
├── index.html          the whole app (passenger + driver interfaces)
├── manifest.json       tells phones "this is installable" (name, colours, icons, shortcuts)
├── sw.js               service worker: offline support + saved map tiles
├── icons/              app icons (any, maskable, Apple, favicon, SVG)
├── _headers            Netlify: makes phones always check for a new sw.js
├── .nojekyll           GitHub Pages: serve files as-is
└── screenshots/        for your slides / write-up
```

## The 10 parts

| # | Part | Status |
|---|------|--------|
| 1 | Project setup and folder structure | Done |
| 2 | App icons (192, 512, maskable, Apple touch, favicon, SVG) | Done |
| 3 | `manifest.json` (name, colours, icons, 3 home-screen shortcuts) | Done |
| 4 | Service worker `sw.js` (offline app, saved map tiles, update handling) | Done |
| 5 | Manifest and service worker linked in `index.html` | Done |
| 6 | Phone polish: full-screen layout, notch/home-bar safe areas, theme colour, offline banner, in-app Install button | Done |
| 7 | Test installability locally | **You: steps below** |
| 8 | Put it online (free hosting) | **You: steps below** |
| 9 | Install and test on real phones | **You: steps below** |
| 10 | Demo-day checklist | **You: below** |

Already checked in a headless Chrome: manifest valid, all icons load, Chrome reports **no installability
errors**, service worker activates, the app reloads with the network off, and the offline banner shows.
Not checked: a real phone, and the live satellite/3D map tiles (they need internet).

---

## Part 7 — Test it on your computer

A service worker only runs on `https://` or `http://localhost` — **not** if you double-click the file.

1. Open the folder in VS Code and install the **Live Server** extension, then right-click `index.html` → *Open with Live Server*.
   (Or in a terminal inside the folder: `python -m http.server 8000` and open `http://localhost:8000`.)
2. In Chrome press **F12** → **Application** tab:
   - **Manifest**: name, icons and "Installability" should show no errors.
   - **Service Workers**: `sw.js` should say *activated and is running*.
3. Tick **Offline** (Application → Service Workers), reload — the app should still open and show "Offline — showing saved data".
4. **Lighthouse** tab → run *Progressive Web App* / *Best practices*. Screenshot your score for the judges.
5. In the address bar you should see an **install** icon. Click it to install on your computer.

## Part 8 — Put it online (free)

**Option A — Netlify (easiest, about 2 minutes):**
1. Go to app.netlify.com → *Add new site* → *Deploy manually*.
2. Drag the whole `vincyride-pwa` folder onto the page. You get a link like `https://something.netlify.app`.
3. (Optional) *Site settings → Change site name* to `vincyride`.

**Option B — GitHub Pages:**
1. Create a GitHub repository and upload everything in this folder (keep the files at the top level).
2. *Settings → Pages → Deploy from a branch → main / (root) → Save*.
3. After about a minute your site is at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

Both are `https`, so install and offline work. **Every time you change the app, open `sw.js` and change
`const VERSION = 'v1'` to `'v2'`, `'v3'`… before re-uploading.** Otherwise phones may keep showing the old version.

## Part 9 — Install and test on real phones

**Android (Chrome):** open your link → wait a few seconds → tap **Install VincyRide** (or ⋮ menu → *Install app*).
The in-app card is also under **Profile → Get the VincyRide app**.

**iPhone (Safari only):** open your link in **Safari** → tap **Share** → **Add to Home Screen**.
(iPhones don't show an automatic install button — this is normal.)

Then test on the *installed* app:
- [ ] Opens full-screen with no browser bar; the icon looks right
- [ ] Sign in as passenger (784-555-0123 / 1234) and driver (784-555-0199 / 1234)
- [ ] Find a Ride, Map (Street / Satellite / 3D), Report a Problem, Taxi Finder all work
- [ ] Turn on **airplane mode**, close and reopen the app — it still opens with the "Offline" banner
- [ ] Turn internet back on — banner goes away, map returns
- [ ] Long-press the icon (Android) — you get shortcuts: *Find a Ride, Road Alerts, Taxi Finder*
- [ ] Test on the **cheapest, oldest** phone you can borrow. If the 3D map is slow, demo Satellite instead.

## Part 10 — Demo-day checklist

**The night before**
- [ ] Deploy the final version (remember to bump `VERSION` in `sw.js`)
- [ ] Open it on every demo phone **with internet**, sign in once, and open the Map screen, so the app and map tiles are saved
- [ ] Install it on the demo phones; charge them; turn off auto-lock
- [ ] Record a screen video of the full demo as a backup
- [ ] Verify anything shown as a fact: van numbers, fares, taxi phone numbers, the hospital / NEMO numbers

**At the venue**
- [ ] Phone hotspot ready in case venue Wi-Fi fails (the Simple map and saved data still work with no internet)
- [ ] Two phones ready: one signed in as **Driver**, one as **Passenger** — the seat-count change is your best moment
- [ ] Keep the laptop version open in a browser tab as a spare

**Suggested 3-minute path**
1. Problem: nobody knows if the van is full or has left
2. Passenger phone: Find a Ride, look for van 25, see "5/14 seats · boarding"
3. Passenger: tap **Waiting for a van?**, pin Arnos Vale → Villa. Driver: the icon at Arnos Vale fills with orange
4. Driver: tap **+** a few times, then **Leaving now**; passenger side says "Left"
5. Report a hazard, then show it on the 3D satellite map
6. Turn on airplane mode: the app still works. Close with the roadmap

## Be honest about these (judges will ask)

- Sign-in is **demo-only** (accounts stay in the browser; no SMS). A real launch needs server-side sign-in with a one-time code.
- Seat counts, taxi availability and reports are **simulated**; the two-phone demo shares data only inside one browser.
  Real sharing needs a small backend (for example Supabase or Firebase).
- **Route numbers** other than Villa = 25 (and the 58-route structure), **fares, times, taxi numbers** are sample values. Waiting-passenger crowds are seeded sample data until real people pin stops.
- Satellite imagery is recent photography, not live. The free map tiles are for demos; a public launch needs a keyed provider.

## New in this version: 58 numbered routes + "I'm waiting here"

**Routes 1 to 58.** Every route has a number. **Villa = 25 is the only confirmed number.** The rest (and the
structure: one Kingstown route to each of the 53 other stops, plus 5 links between villages) is a **sample** to
replace with the real van numbers. Sample numbers show a dashed border on their badge. Search by number
(Find a Ride, Bus Routes) or by place.

**Passenger pins where they are waiting.** Home → "Waiting for a van?" (or *I'm waiting here* on any map stop, or *Use my
location* to find the nearest stop). Pick your stop and destination; the app shows which van numbers to look for.
A pin expires after 45 minutes, or when the passenger taps *A van picked me up*.

**Driver sees the crowd.** On the driver's *Today* and *Route* screens every stop has a three-person icon:
**grey = nobody, orange rises the more people are waiting, fully orange = 8 or more** (`CROWD_FULL` in `index.html`).
It only counts people going somewhere *on that driver's route*. Drivers see counts per stop only, never names
or exact location.

**Two-screen demo on one laptop:** open the app in two browser tabs, sign in as passenger in one and driver
(784-555-0199) in the other. Pin a stop in the passenger tab and the driver tab updates by itself.
(Two separate phones need a small backend to share data; see "Be honest about these".)

## Demo accounts

| Role | Phone | PIN |
|------|-------|-----|
| Passenger | 784-555-0123 | 1234 |
| Driver (van 25, Kingstown ↔ Villa) | 784-555-0199 | 1234 |

Profile → *Reset demo data* (driver) clears seat counts and runs before a fresh demo.
